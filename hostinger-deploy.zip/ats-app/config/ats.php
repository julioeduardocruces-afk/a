<?php

return [
    /*
    |--------------------------------------------------------------------------
    | AI Provider
    |--------------------------------------------------------------------------
    | Which AI provider to use: 'openai' or 'gemini'.
    | Managed by admin via api_credentials table.
    */
    'ai_provider' => env('ATS_AI_PROVIDER', 'openai'),

    /*
    |--------------------------------------------------------------------------
    | Price (CLP)
    |--------------------------------------------------------------------------
    | Price in CLP for CV optimization service.
    */
    'price_clp' => (int)env('ATS_PRICE_CLP', 4990),

    /*
    |--------------------------------------------------------------------------
    | wkhtmltoimage path
    |--------------------------------------------------------------------------
    */
    'wkhtmltoimage_path' => env('WKHTMLTOIMAGE_PATH', '/usr/local/bin/wkhtmltoimage'),

    /*
    |--------------------------------------------------------------------------
    | Upload constraints
    |--------------------------------------------------------------------------
    */
    'max_upload_size_mb' => (int)env('ATS_MAX_UPLOAD_MB', 10),

    /*
    |--------------------------------------------------------------------------
    | Download token TTL (minutes)
    | Default: 10080 = 7 days
    |--------------------------------------------------------------------------
    */
    'download_token_ttl' => (int)env('ATS_DOWNLOAD_TOKEN_TTL', 10080),

    /*
    |--------------------------------------------------------------------------
    | Max downloads per token
    |--------------------------------------------------------------------------
    */
    'max_downloads' => (int)env('ATS_MAX_DOWNLOADS', 3),

    /*
    |--------------------------------------------------------------------------
    | Admin notification email
    |--------------------------------------------------------------------------
    | Email address to receive alerts when a paid resume fails processing.
    | Leave empty to disable notifications.
    */
    'admin_notification_email' => env('ATS_ADMIN_NOTIFICATION_EMAIL', ''),

    /*
    |--------------------------------------------------------------------------
    | USD to CLP exchange rate (for AI cost estimation)
    |--------------------------------------------------------------------------
    */
    'usd_to_clp' => (float)env('ATS_USD_TO_CLP', 950),
];
