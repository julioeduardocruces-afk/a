<?php

return [
    /*
    |--------------------------------------------------------------------------
    | AI Provider
    |--------------------------------------------------------------------------
    | Which AI provider to use: 'openai' or 'gemini'.
    | Managed by admin via api_credentials table.
    */
    'ai_provider' => env('ATS_AI_PROVIDER', 'openai'),

    /*
    |--------------------------------------------------------------------------
    | Price (CLP)
    |--------------------------------------------------------------------------
    | Price in CLP for CV optimization service.
    */
    'price_clp' => (int)env('ATS_PRICE_CLP', 4990),

    /*
    |--------------------------------------------------------------------------
    | wkhtmltoimage path
    |--------------------------------------------------------------------------
    */
    'wkhtmltoimage_path' => env('WKHTMLTOIMAGE_PATH', '/usr/local/bin/wkhtmltoimage'),

    /*
    |--------------------------------------------------------------------------
    | Upload constraints
    |--------------------------------------------------------------------------
    */
    'max_upload_size_mb' => (int)env('ATS_MAX_UPLOAD_MB', 10),

    /*
    |--------------------------------------------------------------------------
    | Download token TTL (minutes)
    |--------------------------------------------------------------------------
    */
    'download_token_ttl' => (int)env('ATS_DOWNLOAD_TOKEN_TTL', 15),
];
