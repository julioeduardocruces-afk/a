@extends('layouts.app')
@section('title', 'Subir CV')
@section('meta_description', 'Sube tu CV en PDF o DOCX y optimizalo para sistemas ATS. Sin registro necesario. Compatible con Laborum, ChileTrabajos y principales portales de empleo.')
@section('meta_keywords', 'subir CV, cargar curriculum, optimizar CV online, CV PDF, CV DOCX, subir curriculum Chile')
@push('fb_events')
<script>
(function(){
    var key='fbq_vc_upload';
    if(typeof fbq==='function'&&!sessionStorage.getItem(key)){
        var eid={!! json_encode(session('meta_capi_vc_upload', '')) !!};
        var opts=eid?{eventID:eid}:{};
        fbq('track','ViewContent',{content_name:'CV Upload Page',content_category:'ATS Optimization'},opts);
        sessionStorage.setItem(key,'1');
    }
})();
</script>
@endpush
@section('content')
<div style="max-width:600px;margin:30px auto;">
    <h1 style="margin-bottom:8px;">Paso 1: Sube tu CV</h1>
    <p style="color:#666;margin-bottom:20px;">Sube tu CV y nosotros lo optimizamos para sistemas ATS. Sin registro necesario.</p>
    <div class="card">
        <form method="POST" action="{{ route('upload.store') }}" enctype="multipart/form-data" id="upload-form">
            @csrf
            <div class="form-group">
                <label for="cv_file">Archivo CV (PDF o DOCX, max 10 MB)</label>
                <input type="file" id="cv_file" name="cv_file" accept=".pdf,.docx" required>
            </div>
            <p style="font-size:0.9rem;color:#666;margin-bottom:16px;">
                Formatos aceptados: PDF, DOCX. Archivos DOC antiguos no son compatibles.
                El archivo se almacena de forma segura y privada.
            </p>
            <button type="submit" class="btn btn-primary" style="width:100%;">Subir CV</button>
        </form>
    </div>
    <div class="card" style="text-align:center;background:#f0f7ff;border:1px dashed #0066ff;">
        <p style="margin-bottom:8px;font-weight:600;">No tienes tu CV en archivo?</p>
        <a href="{{ route('cv-builder.form') }}" class="btn btn-success">Crear CV desde Formulario</a>
        <p style="font-size:0.85rem;color:#666;margin-top:8px;">Completa tus datos y nosotros generamos tu CV optimizado.</p>
    </div>
    <div style="margin-top:16px;text-align:center;">
        <a href="{{ route('home') }}">Volver al inicio</a>
    </div>
</div>
@endsection
